def two_sum(A, target):
    
    set_a = set(A)
    for elem in A:
        if target - elem in set_a:
            return True

    return False