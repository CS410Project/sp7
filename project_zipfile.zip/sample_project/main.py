A = [i - 5 for i in range(10)]
B = [i - 1000 for i in range(2000)]

from two_sum import two_sum

assert(two_sum(A, 0))
assert(two_sum(B, 0))